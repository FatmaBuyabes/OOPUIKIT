import UIKit


// Task 1
struct Person {
    var name: String
    var age: String
    var dob: String
}

var fatma = Person(name: "Fatma", age: "23", dob: "1/10/2000")

var awdhah = Person(name: "Awdhah", age: "23", dob: "27/7/2000")

print(fatma)

print(awdhah.dob)


// Task 2

struct employee {
    var id: Int
    var name: String
    var dept: String
    
    func printDetails(){
        print("Employye Name: \(name), ID: \(id), Department: \(dept)")
        
    }
    
}

class company{
    var employees: [employee] = []
    
    func addEmployee(employee: employee){
        employees.append(employee)
    }
    func employeeList(){
        for employee in employees{
            employee.printDetails()
        }
    }
    
}

var kfhCompany = company()
var fatmaEmployee = employee(id: 83329, name: "fatma", dept: "IT")
var awdhahEmployee = employee(id: 83318, name: "Awdhah", dept: "IT")

kfhCompany.addEmployee(employee: fatmaEmployee)
kfhCompany.addEmployee(employee: awdhahEmployee)

kfhCompany.employeeList()

kfhCompany.employees.count
